public class StockInfo
{
	public String ID;
	public String TITLE;
	public String AUTHOR;
	public String DATE;
	public String LASTUPDATE;
	public String CONTENT;
	public String ANSWERAUTHOR;
	public String ANSWER;
	public int l ;
}
