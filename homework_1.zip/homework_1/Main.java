import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.nio.file.*;
import java.io.FileOutputStream;

public class Main implements FileHandler, StockSorter {

	// ����
	public StockInfo[] si = new StockInfo[10001];
	boolean ascending = true/* ���� */, descending = false;/* ���� */

	// ���
	public static void main(String[] args) throws IOException {
		Main temp1 = new Main();
		StockInfo[] tmp = temp1.getStockInfoFromFile("src/data.txt");
		// temp1.sort(tmp, temp1.descending);
		temp1.sort1(tmp);
		temp1.setStockInfo2File("src/datanew.txt", tmp);

	}

	// ����ʵ��
	// ��ȡ�ļ�
	public StockInfo[] getStockInfoFromFile(String filePath) throws IOException {

		FileInputStream fip = new FileInputStream(filePath);
		Scanner scan1 = new Scanner(fip, "utf-8").useDelimiter("\t");
		int i = 0;
		for (i = 0; i < 10001; i++) {
			si[i] = new StockInfo();
			si[i].ID = scan1.next();
			si[i].TITLE = scan1.next();
			si[i].AUTHOR = scan1.next();
			si[i].DATE = scan1.next();
			si[i].LASTUPDATE = scan1.next();
			si[i].CONTENT = scan1.next();
			si[i].ANSWERAUTHOR = scan1.next();
			scan1.useDelimiter("\n");
			si[i].ANSWER = scan1.next();
			si[i].l = si[i].ANSWER.length();
			scan1.useDelimiter("\t");
		}
		scan1.close();
		fip.close();
		return si;
	}

	// д���ļ�
	public int setStockInfo2File(String filePath, StockInfo[] info) throws IOException {
		OutputStream fop = new FileOutputStream(filePath);
		OutputStreamWriter writer = new OutputStreamWriter(fop, "UTF-8");
		for (int i = 0; i < info.length; i++) {
			writer.write(info[i].ID + '\t' + info[i].TITLE + '\t' + info[i].AUTHOR + '\t' + info[i].DATE + '\t'
					+ info[i].LASTUPDATE + '\t' + info[i].CONTENT + '\t' + info[i].ANSWERAUTHOR + '\t' + info[i].ANSWER
					+ '\r' + '\n');
		}
		fop.close();
		return 0;
	}

	// ð������
	public StockInfo[] sort(StockInfo[] info) {
		StockInfo si = new StockInfo();
		for (int i = info.length - 2; i > 1; i--) {
			for (int j = 1; j <= i; j++) {
				if (info[j].l > info[j + 1].l) {
					si = info[j + 1];
					info[j + 1] = info[j];
					info[j] = si;
				}
			}
		}
		return info;
	}

	// ���򷽷�2��ץ������
	public StockInfo[] sort1(StockInfo[] info) {
		for (int i = 2; i < info.length - 1; i++) {
			StockInfo get = info[i];
			int j = i - 1;
			while (j >= 1 && info[j].l > get.l) {
				info[j + 1] = info[j];
				j--;
			}
			info[j + 1] = get;
		}
		return info;
	}

	// ���򷽷�3��ѡ������ ����
	public StockInfo[] sort2(StockInfo[] info) {
		StockInfo[] newsi = info;
		int j = 1;
		for (int i = 1; i < info.length; i++) {
			newsi[i] = info[i];
			for (int k = 1; k < info.length; k++) {
				if (newsi[i].l < info[k].l) {
					newsi[i] = info[k];
					j = k;
				}
			}
			info[j].l = -1;
		}
		return info;
	}

	// ����
	public StockInfo[] sort(StockInfo[] info, boolean order) {
		StockInfo si = new StockInfo();
		for (int i = info.length - 2; i > 1; i--) {
			for (int j = 1; j <= i; j++) {
				if (order) {
					if (info[j].l > info[j + 1].l) {
						si = info[j + 1];
						info[j + 1] = info[j];
						info[j] = si;
					}
				} else {
					if (info[j].l < info[j + 1].l) {
						si = info[j + 1];
						info[j + 1] = info[j];
						info[j] = si;
					}
				}
			}
		}
		return info;
	}

	// ����̨���
	public void showStockInfo(StockInfo[] info) {
		int i = 0;
		while (i < 10001) {
			System.out.println(info[i].ID + " " + info[i].TITLE + " " + info[i].AUTHOR + " " + info[i].DATE + " "
					+ info[i].LASTUPDATE + " " + info[i].ANSWERAUTHOR + " " + info[i].ANSWER);
			i++;
		}
	}
}