package tf_idf;

import javafx.util.Pair;
import util.StockSorter;
import vo.StockInfo;

import java.util.List;

public class TF_IDFImpl implements TF_IDF {
    /**
     * this func you need to calculate words frequency , and sort by frequency.
     * you maybe need to use the sorter written by yourself in example 1
     *
     * @param words the word after segment
     * @return a sorted words
     * @see StockSorter
     */
    @Override
    public Pair<String, Double>[] getResult(List<String> words, StockInfo[] stockInfos) {
        //TODO: write your code here
        return null;
    }
}
