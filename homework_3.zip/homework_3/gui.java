import com.gsoft.ncs.gui.res.StrPicker;
import com.gsoft.ncs.gui.startup.Application;
import com.gsoft.ncs.utils.i18n.I18NEvent;
import com.gsoft.ncs.utils.i18n.I18NListener;

import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FrmChooserAct extends AbstractAction
        implements I18NListener
{
    private static final Log logger = LogFactory.getLog(FrmChooserAct.class);
    private static final long serialVersionUID = 1L;
    private static final StrPicker picker = StrPicker.instance();
    private static FrmChooserAct instance = null;
    private File[] file;
    private File file1;
    private int n;
    private String[] srcFilePath;
    private String targetFileDir;
    private boolean b;

    private FrmChooserAct() {
        super(picker.getString("menu.jfileChooser"));
        putValue("ShortDescription", picker.getString("tip.jfileChooser"));
        StrPicker.addI18NListener(this);
    }

    public static FrmChooserAct instance() {
        if (null == instance) {
            instance = new FrmChooserAct();
        }
        return instance;
    }
    public void actionPerformed(ActionEvent e) {
        JFileChooser c = new JFileChooser();
        c.setAcceptAllFileFilterUsed(false);
        c.setMultiSelectionEnabled(true);
        c.addChoosableFileFilter(new FileFilter() {

            @Override
            public boolean accept(File f) {
                if (f.isDirectory()) {// 如果是目录就可以访问
                    return true;
                }
                if (f.getName().endsWith(".mib")) {// 如果是,txt文件格式的文件,那么就可以显示出来
                    return true;
                }
                return false;
            }

            @Override
            public String getDescription() {
                return "*.mib";
            }

        });
        int rVal = c.showOpenDialog(Application.frame);
        if (rVal == JFileChooser.APPROVE_OPTION) {
            file = c.getSelectedFiles();
            n = c.getSelectedFiles().length;
            srcFilePath = new String[n];
            String fileSeparator = System.getProperty("file.separator");
            targetFileDir = System.getProperty("user.dir")+fileSeparator+"resources/mibfiles";
            for (int i = 0; i < n; i++) {
                srcFilePath[i] = file[i].toString();
                b = copyToFile(srcFilePath[i], targetFileDir);
            }
        }

        // if(rVal == JFileChooser.CANCEL_OPTION){
        // System.exit(0);
        // }
/*    */   }

    public static boolean copyToFile(String srcFilePath, String targetFileDir) {
        boolean result = true;
        BufferedReader ifStream = null;
        PrintWriter ofStream = null;
        File srcFile = new File(srcFilePath);
        String fileName = srcFile.getName();
        String fileSeparator = System.getProperty("file.separator");
        String targetFilePath = targetFileDir + fileSeparator + fileName;
        System.out.println(targetFilePath);
        File file=new File(targetFilePath);
        if(!file.exists())
        {
            try {
                ifStream = new BufferedReader(new FileReader(srcFilePath));
                ofStream = new PrintWriter(new FileWriter(targetFilePath));
                String line;
                while ((line = ifStream.readLine()) != null) {
                    ofStream.print(line);
                    ofStream.print("\r\n");// 文件中的回车换行
                }
                ifStream.close();
                ofStream.close();
                ChooserSuccessDialog.instance();
            } catch (FileNotFoundException e) {
                System.out.println("源文件路径错误！");
                result = false;
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("目标文件路径错误！");
                result = false;
                e.printStackTrace();
            } finally {
                try {
                    ifStream.close();
                } catch (IOException e) {
                    System.out.println("源文件关闭错误！");
                    result = false;
                    e.printStackTrace();
                } finally {
                    ofStream.close();
                }
                ofStream.close();
            }
        }else{
            repeatDialog.instance();
        }

        return result;
    }

    public void localeChanged(I18NEvent event) {
        putValue("Name", StrPicker.instance().getString("menu.jfileChooser"));
        putValue("ShortDescription", StrPicker.instance().getString("tip.jfileChooser"));
    }
}