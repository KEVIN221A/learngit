package vo;

public class UserInterest {
}
