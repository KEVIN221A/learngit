package vo;

public class StockInfo {
}
