package segmenter;


import com.sun.org.apache.xerces.internal.xs.StringList;
import org.ansj.recognition.impl.StopRecognition;
import vo.StockInfo;

import java.util.*;

import org.ansj.recognition.impl.StopRecognition;
import vo.StockInfo;

import java.util.*;

import org.ansj.domain.Result;
import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.ToAnalysis;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.List;

public class ChineseSegmenterImpl implements ChineseSegmenter {

    //只关注这些词性的词
  /*  Set<String> expectedNature = new HashSet<String>() {{
        add("n");
        add("v");
        add("vd");
        add("vn");
        add("vf");
        add("vx");
        add("vi");
        add("vl");
        add("vg");
        add("nt");
        add("nz");
        add("nw");
        add("nl");
        add("ng");
        add("userDefine");
        add("wh");
    }};*/


    /**
     * this func will get chinese word from a list of stocks. You need analysis stocks' answer and get answer word.
     * And implement this interface in the class : ChineseSegmenterImpl
     * Example: 我今天特别开心 result : 我 今天 特别 开心
     *
     * @param stocks stocks info
     * @return chinese word
     * @see ChineseSegmenterImpl
     */
    @Override
    public List<String> getWordsFromInput(StockInfo[] stocks) {

        List <String> words = new ArrayList<>();

        StopRecognition filter = new StopRecognition();
        filter.insertStopNatures("uj");
        filter.insertStopNatures("ul");
        filter.insertStopNatures("null");
        filter.insertStopNatures("w");
        filter.insertStopRegexes(".*?\\w.*?");
        filter.insertStopRegexes("\\s");

        //TODO: write your code here

        for(int k=1;k<stocks.length;k++){
            Result result = ToAnalysis.parse(stocks[k].getAnswer()).recognition(filter);
            List<Term> terms = result.getTerms();
            /*for (int i = 0; i < terms.size(); i++) {
                String word = terms.get(i).getName();
                String natureStr = terms.get(i).getNatureStr();
                if (expectedNature.contains(natureStr)) {
                    words.add(word);
                }*/
                for (int j = 0; j < terms.size(); j++) {
                    words.add(terms.get(j).getName());
                }

            }

        return words;
    }


    public List<String> getWordsFromInputContent (StockInfo[] stocks) {

        List <String> words = new ArrayList<>();

        StopRecognition filter = new StopRecognition();
        filter.insertStopNatures("uj");
        filter.insertStopNatures("ul");
        filter.insertStopNatures("null");
        filter.insertStopNatures("w");
        filter.insertStopRegexes(".*?\\w.*?");
        filter.insertStopRegexes("\\s");

        //TODO: write your code here

        for(int k=1;k<stocks.length;k++){
            Result result = ToAnalysis.parse(stocks[k].getContent()).recognition(filter);
            List<Term> terms = result.getTerms();
           /* for (int i = 0; i < terms.size(); i++) {
                String word = terms.get(i).getName();
                //String natureStr = terms.get(i).getNatureStr();
                if (expectedNature.contains(natureStr)) {
                    words.add(word);
                }*/
                for (int j = 0; j < terms.size(); j++) {
                    words.add(terms.get(j).getName());
                }

            }
        return words;
    }
}




